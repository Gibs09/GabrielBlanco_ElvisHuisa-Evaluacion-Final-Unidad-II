package model;

import java.sql.Date;

/**
 * Clase que representa la entidad Empleado.
 * Mapea directamente la tabla 'empleado' de la base de datos.
 */
public class Empleado {

    // Atributos privados para encapsulamiento
    private int idEmpleado;
    private String nombreEmpleado;
    private Date fechaInicio;
    private Date fechaTermino; // Puede ser null si el contrato es indefinido
    private String tipoContrato;
    private boolean planSalud; // true = Si, false = No
    private boolean afp;       // true = Si, false = No

    // CONSTRUCTORES

    public Empleado() {
    }
    public Empleado(int idEmpleado, String nombreEmpleado, Date fechaInicio, Date fechaTermino, String tipoContrato, boolean planSalud, boolean afp) {
        this.idEmpleado = idEmpleado;
        this.nombreEmpleado = nombreEmpleado;
        this.fechaInicio = fechaInicio;
        this.fechaTermino = fechaTermino;
        this.tipoContrato = tipoContrato;
        this.planSalud = planSalud;
        this.afp = afp;
    }

    // GETTERS Y SETTERS

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        // Mejora: Evitar guardar nombres con espacios extra al inicio o final
        if (nombreEmpleado != null) {
            this.nombreEmpleado = nombreEmpleado.trim();
        } else {
            this.nombreEmpleado = "";
        }
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaTermino() {
        return fechaTermino;
    }

    public void setFechaTermino(Date fechaTermino) {
        this.fechaTermino = fechaTermino;
    }

    public String getTipoContrato() {
        return tipoContrato;
    }

    public void setTipoContrato(String tipoContrato) {
        // Mejora: Limpieza de espacios
        if (tipoContrato != null) {
            this.tipoContrato = tipoContrato.trim();
        } else {
            this.tipoContrato = "Indefinido"; // Valor por defecto seguro
        }
    }

    public boolean isPlanSalud() {
        return planSalud;
    }

    public void setPlanSalud(boolean planSalud) {
        this.planSalud = planSalud;
    }

    public boolean isAfp() {
        return afp;
    }

    public void setAfp(boolean afp) {
        this.afp = afp;
    }

    // MÉTODOS DE UTILIDAD

    /**
     * Método toString.
     * Convierte el objeto a texto. Indispensable para hacer System.out.println(objeto)
     * y ver qué datos tiene cargados al buscar errores.
     */
    
    @Override
    public String toString() {
        return "Empleado {" +
                "ID=" + idEmpleado +
                ", Nombre='" + nombreEmpleado + '\'' +
                ", Inicio=" + fechaInicio +
                ", Termino=" + fechaTermino +
                ", Contrato='" + tipoContrato + '\'' +
                ", Salud=" + (planSalud ? "Sí" : "No") +
                ", AFP=" + (afp ? "Sí" : "No") +
                '}';
    }
}