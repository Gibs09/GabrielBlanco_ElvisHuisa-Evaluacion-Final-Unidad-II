package controller;

import model.Empleado;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ControladorEmpleado {

    // CONSULTAS SQL CONSTANTES

    private static final String SQL_INSERT = "INSERT INTO empleado (idEmpleado, nombreEmpleado, fechaInicio, fechaTermino, tipoContrato, planSalud, afp) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_SELECT = "SELECT * FROM empleado";
    private static final String SQL_UPDATE = "UPDATE empleado SET nombreEmpleado=?, fechaInicio=?, fechaTermino=?, tipoContrato=?, planSalud=?, afp=? WHERE idEmpleado=?";
    private static final String SQL_DELETE = "DELETE FROM empleado WHERE idEmpleado=?";

    // MÉTODOS CRUD


    /**
     * CREATE: Agrega un nuevo empleado a la base de datos.
     */

    public boolean agregarRegistro(Empleado emp) {
        try (Connection con = Conexion.getConexion()) {
            
            // Validación de seguridad: Verificar si hay conexión antes de usarla
            if (con == null) {
                System.err.println("Error: No hay conexión con la base de datos.");
                return false;
            }

            try (PreparedStatement ps = con.prepareStatement(SQL_INSERT)) {
                ps.setInt(1, emp.getIdEmpleado());
                ps.setString(2, emp.getNombreEmpleado());
                ps.setDate(3, emp.getFechaInicio());
                ps.setDate(4, emp.getFechaTermino()); // Puede ser null, JDBC lo maneja
                ps.setString(5, emp.getTipoContrato());
                ps.setBoolean(6, emp.isPlanSalud());
                ps.setBoolean(7, emp.isAfp());

                // executeUpdate > 0 significa que se insertó al menos 1 fila
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error al agregar registro: " + e.getMessage());
            return false;
        }
    }

    /**
     * READ: Obtiene todos los empleados.
     */

    public List<Empleado> cargarRegistros() {
        List<Empleado> lista = new ArrayList<>();
        
        try (Connection con = Conexion.getConexion()) {
            if (con == null) return lista; // Retornar lista vacía si no hay conexión

            try (Statement st = con.createStatement(); 
                 ResultSet rs = st.executeQuery(SQL_SELECT)) {

                while (rs.next()) {
                    Empleado emp = new Empleado(
                        rs.getInt("idEmpleado"),
                        rs.getString("nombreEmpleado"),
                        rs.getDate("fechaInicio"),
                        rs.getDate("fechaTermino"),
                        rs.getString("tipoContrato"),
                        rs.getBoolean("planSalud"),
                        rs.getBoolean("afp")
                    );
                    lista.add(emp);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar registros: " + e.getMessage());
        }
        return lista;
    }

    /**
     * UPDATE: Modifica un empleado existente.
     * Retorna true SOLO si el ID existía y se modificó.
     */

    public boolean modificarRegistro(Empleado emp) {
        try (Connection con = Conexion.getConexion()) {
            if (con == null) return false;

            try (PreparedStatement ps = con.prepareStatement(SQL_UPDATE)) {
                ps.setString(1, emp.getNombreEmpleado());
                ps.setDate(2, emp.getFechaInicio());
                ps.setDate(3, emp.getFechaTermino());
                ps.setString(4, emp.getTipoContrato());
                ps.setBoolean(5, emp.isPlanSalud());
                ps.setBoolean(6, emp.isAfp());
                
                // El ID va al final en el WHERE
                ps.setInt(7, emp.getIdEmpleado());

                // executeUpdate devuelve el número de filas afectadas.
                // Si devuelve 0, significa que el ID no existía, por lo tanto return false.
                int filasAfectadas = ps.executeUpdate();
                return filasAfectadas > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error al modificar registro: " + e.getMessage());
            return false;
        }
    }

    /**
     * DELETE: Elimina un empleado por su ID.
     * Retorna true SOLO si el ID existía y se eliminó.
     */
    public boolean eliminarRegistro(int id) {
        try (Connection con = Conexion.getConexion()) {
            if (con == null) return false;

            try (PreparedStatement ps = con.prepareStatement(SQL_DELETE)) {
                ps.setInt(1, id);

                // Si intentas borrar el ID X y no existe, esto devolverá 0 (false),
                // lo cual es correcto para avisar al usuario.
                int filasAfectadas = ps.executeUpdate();
                return filasAfectadas > 0;
            }
        } catch (SQLException e) {
            // Error SQL real (ej. restricción de llave foránea)
            System.err.println("Error al eliminar registro: " + e.getMessage());
            return false;
        }
    }
}