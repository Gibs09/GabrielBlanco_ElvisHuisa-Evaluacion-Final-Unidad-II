package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    // Constantes de conexión
 
    private static final String URL = "jdbc:mysql://localhost:3306/pagosbd"; 
    private static final String USER = "root"; 
    private static final String PASSWORD = ""; 

    // Constructor 
    
    private Conexion() {
    }

    /**
     * Obtiene una nueva conexión a la base de datos.
     * @return Objeto Connection o null si falla.
     */
    public static Connection getConexion() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
            
        } catch (SQLException e) {
            // Usamos System.err para que el error salga en rojo en la consola
            System.err.println("Error CRÍTICO de conexión a la Base de Datos:");
            System.err.println("Mensaje: " + e.getMessage());
            
            // Sugerencia común de error
            if (e.getMessage().contains("Access denied")) {
                System.err.println("Verifica tu usuario y contraseña en Conexion.java");
            } else if (e.getMessage().contains("Communications link failure")) {
                System.err.println("Verifica que XAMPP/MySQL esté encendido.");
            } else if (e.getMessage().contains("Unknown database")) {
                System.err.println("Verifica que la base de datos 'pagosbd' exista.");
            }
            
            return null;
        }
    }
}