package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder; // Agregado para bordes más limpios
import javax.swing.table.DefaultTableModel;
import controller.ControladorEmpleado;
import model.Empleado;
import java.sql.Date;
import java.util.List;

public class VentanaEmpleado extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblId, lblNombre, lblFechaInicio, lblFechaTermino, lblContrato;
    private JTextField txtId, txtNombre, txtFechaInicio, txtFechaTermino;
    private JComboBox<String> cbContrato;
    private JCheckBox chkSalud, chkAfp;
    private JButton btnAgregar, btnModificar, btnEliminar, btnLimpiar, btnConsultar;
    private JTable tablaEmpleados;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollPane;

    private ControladorEmpleado controlador;

    public VentanaEmpleado() {
        controlador = new ControladorEmpleado();

        // Configuración básica de la ventana
        setTitle("Sistema de Gestión de Pagos - MVP");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 550); // Usar setBounds es mejor que setSize + setLocation
        setResizable(false);
        setLocationRelativeTo(null);

        // 1. Inicializar contentPane antes de usarlo
        contentPane = new JPanel();
        contentPane.setBackground(Color.PINK);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null); 
        setContentPane(contentPane);

        // Métodos de configuración organizados
        configurarCamposDeEntradas();
        configurarBotonesDeEventos();
        configurarTablaDeDatos();
        configurarEventos();
        
        // Cargar datos iniciales
        cargarDatosTabla();
    }

    private void configurarCamposDeEntradas() {
        // Etiquetas y Campos
        lblId = new JLabel("ID Empleado:");
        lblId.setBounds(30, 30, 100, 25);
        contentPane.add(lblId);

        txtId = new JTextField();
        txtId.setBounds(140, 30, 150, 25);
        contentPane.add(txtId);

        lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 70, 100, 25);
        contentPane.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(140, 70, 150, 25);
        contentPane.add(txtNombre);

        lblFechaInicio = new JLabel("F. Inicio (yyyy-mm-dd):");
        lblFechaInicio.setBounds(30, 110, 140, 25);
        contentPane.add(lblFechaInicio);

        txtFechaInicio = new JTextField();
        txtFechaInicio.setBounds(180, 110, 110, 25);


        // Ayuda al usuario con el formato
        txtFechaInicio.setToolTipText("Ejemplo: 2024-01-30"); 
        contentPane.add(txtFechaInicio);

        lblFechaTermino = new JLabel("F. Término (yyyy-mm-dd):");
        lblFechaTermino.setBounds(320, 110, 160, 25);
        contentPane.add(lblFechaTermino);

        txtFechaTermino = new JTextField();
        txtFechaTermino.setBounds(480, 110, 110, 25);
        txtFechaTermino.setEnabled(false);
        contentPane.add(txtFechaTermino);

        lblContrato = new JLabel("Tipo Contrato:");
        lblContrato.setBounds(30, 150, 100, 25);
        contentPane.add(lblContrato);

        cbContrato = new JComboBox<>(new String[] { "Indefinido", "A Plazo"});
        cbContrato.setBounds(140, 150, 150, 25);
        contentPane.add(cbContrato);

        chkSalud = new JCheckBox("Plan de Salud");
        chkSalud.setBounds(320, 30, 120, 25);
        chkSalud.setBackground(Color.PINK); 
        contentPane.add(chkSalud);

        chkAfp = new JCheckBox("AFP");
        chkAfp.setBounds(320, 70, 100, 25);
        chkAfp.setBackground(Color.PINK); 
        contentPane.add(chkAfp);


        // Lógica de UI: Habilitar/Deshabilitar fecha según contrato
        cbContrato.addActionListener(e -> {
            boolean esIndefinido = cbContrato.getSelectedItem().equals("Indefinido");
            txtFechaTermino.setEnabled(!esIndefinido);
            if (esIndefinido) {
                txtFechaTermino.setText("");
            }
        });
    }

    private void configurarBotonesDeEventos() {
        btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(650, 30, 100, 30);
        contentPane.add(btnAgregar);

        btnModificar = new JButton("Modificar");
        btnModificar.setBounds(650, 70, 100, 30);
        contentPane.add(btnModificar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(650, 110, 100, 30);
        contentPane.add(btnEliminar);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(650, 150, 100, 30);
        contentPane.add(btnLimpiar);

        btnConsultar = new JButton("Refrescar");
        btnConsultar.setBounds(650, 190, 100, 30);
        contentPane.add(btnConsultar);
    }

    private void configurarTablaDeDatos() {
        // Hacemos que las celdas no sean editables directamente
        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("F. Inicio");
        modeloTabla.addColumn("F. Término");
        modeloTabla.addColumn("Contrato");
        modeloTabla.addColumn("Salud");
        modeloTabla.addColumn("AFP");

        tablaEmpleados = new JTable(modeloTabla);
        scrollPane = new JScrollPane(tablaEmpleados);
        scrollPane.setBounds(30, 260, 820, 200);
        contentPane.add(scrollPane);
    }

    // 2. Método auxiliar para crear el objeto (evita duplicar código)
    private Empleado obtenerEmpleadoDesdeFormulario() throws IllegalArgumentException {
        Empleado emp = new Empleado();
        
        // Validaciones básicas de parsing
        try {
            emp.setIdEmpleado(Integer.parseInt(txtId.getText()));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El ID debe ser un número entero.");
        }

        emp.setNombreEmpleado(txtNombre.getText());

        try {
            emp.setFechaInicio(Date.valueOf(txtFechaInicio.getText()));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("La fecha de inicio es inválida (use yyyy-mm-dd).");
        }

        if (txtFechaTermino.isEnabled() && !txtFechaTermino.getText().trim().isEmpty()) {
            try {
                emp.setFechaTermino(Date.valueOf(txtFechaTermino.getText()));
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("La fecha de término es inválida (use yyyy-mm-dd).");
            }
        } else {
            emp.setFechaTermino(null);
        }

        emp.setTipoContrato(cbContrato.getSelectedItem().toString());
        emp.setPlanSalud(chkSalud.isSelected());
        emp.setAfp(chkAfp.isSelected());

        return emp;
    }

    private void configurarEventos() {

        // --- BOTÓN AGREGAR ---
        btnAgregar.addActionListener(e -> {
            if (validarCampos()) {
                try {
                    Empleado emp = obtenerEmpleadoDesdeFormulario(); 
                    
                    if (controlador.agregarRegistro(emp)) {
                        JOptionPane.showMessageDialog(this, "Empleado agregado correctamente.");
                        cargarDatosTabla();
                        limpiarCampos();
                    } else {
                        JOptionPane.showMessageDialog(this, "Error: No se pudo agregar (¿ID duplicado?).", "Error BD", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage(), "Error de formato", JOptionPane.WARNING_MESSAGE);
                } catch (Exception ex) {
                    ex.printStackTrace(); // Importante para debug
                    JOptionPane.showMessageDialog(this, "Error inesperado: " + ex.getMessage());
                }
            }
        });

        // --- BOTÓN MODIFICAR ---
        btnModificar.addActionListener(e -> {
            if (validarCampos()) {
                try {
                    // Reutilizamos la misma lógica
                    Empleado emp = obtenerEmpleadoDesdeFormulario(); 
                    
                    if (controlador.modificarRegistro(emp)) {
                        JOptionPane.showMessageDialog(this, "Empleado modificado correctamente.");
                        cargarDatosTabla();
                        limpiarCampos();
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al modificar. Verifique que el ID exista.", "Error BD", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage(), "Error de formato", JOptionPane.WARNING_MESSAGE);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error inesperado.");
                }
            }
        });

        // --- BOTÓN ELIMINAR ---
        btnEliminar.addActionListener(e -> {
            if (!txtId.getText().isEmpty()) {
                int confirm = JOptionPane.showConfirmDialog(this, "¿Seguro que desea eliminar este empleado?", "Confirmar", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        int id = Integer.parseInt(txtId.getText());
                        if (controlador.eliminarRegistro(id)) {
                            JOptionPane.showMessageDialog(this, "Empleado eliminado.");
                            cargarDatosTabla();
                            limpiarCampos();
                        } else {
                            JOptionPane.showMessageDialog(this, "Error al eliminar (¿ID no existe?).");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "El ID debe ser numérico.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Ingrese un ID para eliminar.");
            }
        });

        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnConsultar.addActionListener(e -> cargarDatosTabla());

        // Evento de clic en la tabla
        tablaEmpleados.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = tablaEmpleados.getSelectedRow();
                if (fila >= 0) {
                    try {
                        txtId.setText(modeloTabla.getValueAt(fila, 0).toString());
                        txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                        txtFechaInicio.setText(modeloTabla.getValueAt(fila, 2).toString());
                        
                        Object fechaTermino = modeloTabla.getValueAt(fila, 3);
                        txtFechaTermino.setText(fechaTermino != null ? fechaTermino.toString() : "");

                        String contrato = modeloTabla.getValueAt(fila, 4).toString();
                        cbContrato.setSelectedItem(contrato);
                        
                        // Forzar actualización del estado del campo fechaTermino
                        txtFechaTermino.setEnabled(!contrato.equals("Indefinido"));

                        chkSalud.setSelected((boolean) modeloTabla.getValueAt(fila, 5));
                        chkAfp.setSelected((boolean) modeloTabla.getValueAt(fila, 6));

                        txtId.setEditable(false); // No permitir editar ID al seleccionar de tabla
                    } catch (Exception ex) {
                        System.out.println("Error al seleccionar fila: " + ex.getMessage());
                    }
                }
            }
        });
    }

    private boolean validarCampos() {
        if (txtId.getText().trim().isEmpty() || txtNombre.getText().trim().isEmpty() || txtFechaInicio.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Error: ID, nombre y fecha inicio son obligatorios.", "Validación", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Validación extra: formato de fecha simple con Regex
        if (!txtFechaInicio.getText().matches("\\d{4}-\\d{2}-\\d{2}")) {
            JOptionPane.showMessageDialog(this, "El formato de fecha debe ser yyyy-mm-dd", "Formato Fecha", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        String tipo = cbContrato.getSelectedItem().toString();
        if (!tipo.equals("Indefinido") && txtFechaTermino.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar la fecha de término para contratos NO indefinidos.", "Validación", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtId.setEditable(true); // Volver a habilitar ID para nuevos registros
        txtNombre.setText("");
        txtFechaInicio.setText("");
        txtFechaTermino.setText("");
        cbContrato.setSelectedIndex(0);
        chkSalud.setSelected(false);
        chkAfp.setSelected(false);
        txtFechaTermino.setEnabled(false);
        tablaEmpleados.clearSelection();
    }

    private void cargarDatosTabla() {
        modeloTabla.setRowCount(0); // Limpiar tabla antes de cargar
        List<Empleado> lista = controlador.cargarRegistros();
        for (Empleado e : lista) {
            modeloTabla.addRow(new Object[]{
                e.getIdEmpleado(),
                e.getNombreEmpleado(),
                e.getFechaInicio(),
                e.getFechaTermino(),
                e.getTipoContrato(),
                e.isPlanSalud(),
                e.isAfp()
            });
        }
    }
}