package view;

import javax.swing.UIManager;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                // Instanciar la ventana principal
                VentanaEmpleado miVentana = new VentanaEmpleado();
                miVentana.setVisible(true);

            } catch (Exception e) {
                // MEJORA DE ROBUSTEZ: Capturar errores fatales al inicio
                // Si la base de datos falla o la ventana tiene un error en el constructor,
                // esto nos avisará en lugar de que el programa no haga nada.
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, 
                    "Error fatal al iniciar la aplicación:\n" + e.getMessage(), 
                    "Error de Inicio", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}